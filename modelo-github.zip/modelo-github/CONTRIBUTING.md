# CONTRIBUTING

Comece sendo gentil e agradecendo pela disponibilidade dessa pessoa por querer contribuir com o seu projeto.

## Como Contribuir

Dê dicas de como manter o seu padrão de código ou de evitar conflitos com o seu projeto. Se você seguiu algum guia de estilo para o seu código, esse é um ótimo momento para descrevê-lo ou o compartilhar.

### Modelo de Pull Request / Modelo de Issue

Se possível, deixe aqui algum modelo de PR que o contribuidor deve usar.
Exemplo simples:

Descrição do bug/feature: <br>
Descreva o bug que você corrigiu ou a feature que trabalhou.

Solução adotada: <br>
Descreva o que foi realizado no código.